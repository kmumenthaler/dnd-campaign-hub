"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => DndCampaignHubPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");

// src/templates.ts
var WORLD_TEMPLATE = `---
world: 
campaign: 
status: active
role: player
system:
type: world
fc-calendar: 
fc-date: 
  year: 
  month: 
  day: 
---
# The World of Your Campaign

## Player Characters

\`\`\`dataview
TABLE WITHOUT ID
  link(file.path, name) AS "Name",
  class + choice(subclass, " (" + subclass + ")", "") AS "Class",
  level AS "Level",
  number(ac) AS "AC",
  (hp + "/" + default(hp_max, "?")) + choice(default(thp, 0) > 0, " (+" + thp + " THP)", "") AS "HP",
  default(init_bonus, 0) AS "Initiative",
  default(speed, 30) AS "Speed",
  default(passive_perception, "?") AS "PP",
  choice(readonlyUrl, "[DDB](" + readonlyUrl + ")", "\u2014") AS "D&D Beyond"
FROM "ttrpgs/{{CAMPAIGN_NAME}}/PCs"
WHERE type = "player"
SORT name ASC
\`\`\`

## Sessions

*Create new sessions using the buttons below or the command palette (Ctrl/Cmd+P \u2192 "Create New Session").*

\`\`\`button
name Create New Session
type command
action D&D Campaign Hub: Create New Session
\`\`\`
^button-new-session

\`\`\`button
name Create New NPC
type command
action D&D Campaign Hub: Create New NPC
\`\`\`
^button-new-npc

\`\`\`button
name Create New PC
type command
action D&D Campaign Hub: Create New PC
\`\`\`
^button-new-pc

\`\`\`dataview
table summary as "Summary" from "ttrpgs/{{CAMPAIGN_NAME}}"
where contains(type,"session")
SORT sessionNum ASC
\`\`\`

## Truths about the campaign/world

*Write down some facts about this campaign or the world that the characters find themselves in.*

- 

## Factions

\`\`\`dataview
TABLE description as "Description" from "ttrpgs/{{CAMPAIGN_NAME}}"
WHERE contains(lower(type),"faction")
\`\`\`

## Custom rules

- [[Character options]]
- [[House Rules|House Rules]]

## [[Safety Tools]]
`;
var SESSION_GM_TEMPLATE = `---
type: session
campaign: 
world: 
sessionNum: 
location: 
date: 
fc-calendar: 
fc-date: 
  year: 
  month: 
  day: 
fc-end: 
  year: 
  month: 
  day: 
long_rest: false
short_rest: false
summary: ""
tags: inbox
art: ""
---
# Session 

## Session Summary

> [!tldr] 
>  ^summary

---

## Housekeeping

## Recap

## Strong start

> 

## Scenes

- [ ] 
- [ ] 
- [ ] 
- [ ] 

## Secrets and Clues

- [ ] 
- [ ] 
- [ ] 
- [ ] 
- [ ] 
- [ ] 
- [ ] 
- [ ] 
- [ ] 
- [ ] 

## Loot

- [ ] 

---

## Log

`;
var SESSION_PLAYER_TEMPLATE = `---
type: session
campaign: 
world: 
sessionNum: 
location: 
date: 
fc-calendar: 
fc-date: 
  year: 
  month: 
  day: 
fc-end: 
  year: 
  month: 
  day: 
long_rest: false
short_rest: false
summary: ""
tags: inbox
art: ""
---
# Session

## Session Summary

 > [!tldr] 
>  ^summary

---

## Recap

---

## Log

`;
var NPC_TEMPLATE = `---
type: npc
name: 
age: 
faction: 
location: 
world: 
campaign: 
date: 
description: 
race: 
gender: 
class: 
character-role: 
condition: 
appearance: 
personality: 
background: 
abilities: 
weaknesses: 
behavior: 
statblock: ""
notes: []
tags: ["NPC"]
---

# NPC Name

## Description
Physical description and personality.

## Background
History and motivations.

## Stats
- **STR**: 
- **DEX**: 
- **CON**: 
- **INT**: 
- **WIS**: 
- **CHA**: 

## Abilities
- Ability 1
- Ability 2

## Relationships
- [[Related Character]]
`;
var PC_TEMPLATE = `---
type: pc
player: 
race: 
class: 
level: 1
background: 
alignment: 
experience: 0
---

# Player Character

## Description
Physical description and personality.

## Background
Character backstory.

## Stats
- **STR**:  ( + )
- **DEX**:  ( + )
- **CON**:  ( + )
- **INT**:  ( + )
- **WIS**:  ( + )
- **CHA**:  ( + )

## Skills
- Skill 1: 
- Skill 2: 

## Equipment
- Item 1
- Item 2

## Spells
- Cantrip 1
- Cantrip 2
`;
var ADVENTURE_TEMPLATE = `---
type: adventure
campaign: 
level_range: 
status: planned
---

# Adventure

## Overview
Adventure summary and objectives.

## Key Locations
- [[Location 1]]
- [[Location 2]]

## NPCs
- [[NPC 1]]
- [[NPC 2]]

## Encounters
### Encounter 1
- Description
- Monsters: 
- Treasure: 

## Plot Hooks
- Hook 1
- Hook 2

## Resolution
Adventure conclusion and outcomes.
`;
var FACTION_TEMPLATE = `---
type: faction
alignment: 
leader: 
headquarters: 
influence: 
status: active
---

# Faction

## Description
Faction description and goals.

## Leadership
- [[Leader]]
- Key members

## Influence
Areas where the faction has power.

## Relationships
- Allies: 
- Enemies: 

## Current Activities
What the faction is currently doing.
`;
var ITEM_TEMPLATE = `---
type: item
rarity: common
attunement: no
---

# Item

## Description
Item description and appearance.

## Properties
- Property 1
- Property 2

## History
Item's background and origins.

## Current Location
Where the item is currently located.
`;
var SPELL_TEMPLATE = `---
type: spell
level: 1
school: 
casting_time: 1 action
range: 
components: V, S
duration: 
---

# Spell

## Description
Spell description and effects.

## At Higher Levels
How the spell scales with level.
`;
var CAMPAIGN_TEMPLATE = `---
type: campaign
status: active
dm: 
players: []
start_date: 
current_session: 
---

# Campaign

## Overview
Brief description of the campaign.

## Players
- Player 1
- Player 2

## Key NPCs
- [[NPC Name]]

## Adventures
- [[Adventure Name]]

## Sessions
- [[Session 1]]
`;
var SESSION_DEFAULT_TEMPLATE = `---
type: session
campaign: 
date: 
session_number: 
players_present: []
---

# Session

## Pre-Session Notes
- Objectives
- Plot points to cover
- Potential encounters

## Session Summary
What happened during the session.

## Key Events
- Event 1
- Event 2

## Player Actions
- Player 1: 
- Player 2: 

## Post-Session Notes
- Experience gained
- Treasure distributed
- Plot hooks for next session

## Next Session Prep
- 
`;

// src/main.ts
var DEFAULT_SETTINGS = {
  vaultPath: "",
  currentCampaign: "ttrpgs/Frozen Sick (SOLINA)",
  hotkey: "Ctrl+Shift+M",
  pluginVersion: "0.0.0",
  defaultTemplates: {
    campaign: "",
    npc: "",
    pc: "",
    adventure: "",
    item: "",
    spell: "",
    faction: "",
    session: ""
  }
};
var DndCampaignHubPlugin = class extends import_obsidian.Plugin {
  async onload() {
    await this.loadSettings();
    console.log("D&D Campaign Hub: Plugin loaded");
    await this.checkForUpdates();
    this.addCommand({
      id: "open-dnd-hub",
      name: "Open D&D Campaign Hub",
      callback: () => {
        new DndHubModal(this.app, this).open();
      },
      hotkeys: [
        {
          modifiers: ["Ctrl", "Shift"],
          key: "M"
        }
      ]
    });
    this.addCommand({
      id: "initialize-dnd-hub",
      name: "Initialize D&D Campaign Hub",
      callback: async () => {
        if (this.isVaultInitialized()) {
          new import_obsidian.Notice("D&D Campaign Hub is already initialized in this vault.");
          return;
        }
        await this.initializeVault();
      }
    });
    this.addCommand({
      id: "create-campaign",
      name: "Create New Campaign",
      callback: () => this.createCampaign()
    });
    this.addCommand({
      id: "create-session",
      name: "Create New Session",
      callback: () => this.createSession()
    });
    this.addSettingTab(new DndCampaignHubSettingTab(this.app, this));
  }
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  /**
   * Check if plugin has been updated and notify user
   */
  async checkForUpdates() {
    const manifest = this.manifest;
    const currentVersion = manifest.version;
    const savedVersion = this.settings.pluginVersion;
    if (savedVersion !== currentVersion) {
      if (savedVersion !== "0.0.0") {
        new import_obsidian.Notice(`D&D Campaign Hub updated to v${currentVersion}! Use "Update D&D Hub Templates" to get the latest templates.`, 8e3);
      }
      this.settings.pluginVersion = currentVersion;
      await this.saveSettings();
    }
  }
  /**
   * Update template files without affecting user data
   */
  async updateTemplates() {
    new UpdateConfirmModal(this.app, this).open();
  }
  /**
   * Actually perform the template update after user confirmation
   */
  async performTemplateUpdate() {
    new import_obsidian.Notice("Updating D&D Hub templates...");
    try {
      await this.backupCampaignFiles();
      await this.createTemplateFiles();
      await this.updateExistingCampaignFiles();
      new import_obsidian.Notice("\u2705 Templates updated successfully! Backups saved in z_Backups folder.");
    } catch (error) {
      console.error("Failed to update templates:", error);
      new import_obsidian.Notice("\u274C Failed to update templates. Check console for details.");
    }
  }
  /**
   * Create backups of all template-based campaign files before updating
   */
  async backupCampaignFiles() {
    const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/:/g, "-").split(".")[0];
    const backupFolder = `z_Backups/${timestamp}`;
    try {
      await this.app.vault.createFolder(backupFolder);
    } catch (error) {
    }
    const campaignFiles = this.app.vault.getMarkdownFiles().filter(
      (file) => file.path.startsWith("ttrpgs/")
    );
    for (const file of campaignFiles) {
      try {
        const content = await this.app.vault.read(file);
        const backupPath = file.path.replace(/\//g, "_").replace("ttrpgs_", "");
        const backupFileName = `${backupFolder}/${backupPath}`;
        await this.app.vault.create(backupFileName, content);
      } catch (error) {
        console.error(`Failed to backup ${file.path}:`, error);
      }
    }
  }
  /**
   * Update existing campaign files with new template content while preserving user data
   */
  async updateExistingCampaignFiles() {
    const campaignFiles = this.app.vault.getMarkdownFiles().filter(
      (file) => file.path.startsWith("ttrpgs/")
    );
    for (const file of campaignFiles) {
      try {
        const content = await this.app.vault.read(file);
        const typeMatch = content.match(/^---\n[\s\S]*?type:\s*(.+?)\n[\s\S]*?---/);
        if (!typeMatch) continue;
        const fileType = typeMatch[1].trim();
        switch (fileType) {
          case "world":
            await this.updateWorldFile(file, content);
            break;
          case "npc":
            await this.updateNpcFile(file, content);
            break;
          case "player":
            await this.updatePcFile(file, content);
            break;
          case "adventure":
            await this.updateAdventureFile(file, content);
            break;
          case "session":
          case "session-gm":
          case "session-player":
            await this.updateSessionFile(file, content);
            break;
          case "faction":
            await this.updateFactionFile(file, content);
            break;
          case "item":
            await this.updateItemFile(file, content);
            break;
          case "spell":
            await this.updateSpellFile(file, content);
            break;
        }
      } catch (error) {
        console.error(`Failed to update ${file.path}:`, error);
      }
    }
  }
  /**
   * Update a World.md file
   */
  async updateWorldFile(file, content) {
    const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---\n/);
    if (!frontmatterMatch) return;
    const frontmatter = frontmatterMatch[0];
    const truthsMatch = content.match(/## Truths about the campaign\/world\n\n\*[^*]+\*\n\n([\s\S]*?)(?=\n## |\n*$)/);
    const userTruths = truthsMatch ? truthsMatch[1].trim() : "-";
    const campaignName = file.path.split("/")[1];
    let newContent = WORLD_TEMPLATE.replace(/{{CAMPAIGN_NAME}}/g, campaignName);
    newContent = newContent.replace(/^---\n[\s\S]*?\n---\n/, frontmatter);
    newContent = newContent.replace(
      /(## Truths about the campaign\/world\n\n\*[^*]+\*\n\n)- /,
      `$1${userTruths}
`
    );
    await this.app.vault.modify(file, newContent);
  }
  /**
   * Update template-based files (NPC, PC, Adventure, etc.) by preserving frontmatter
   */
  async updateTemplateBasedFile(file, content, template) {
    const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---\n/);
    if (!frontmatterMatch) return;
    const frontmatter = frontmatterMatch[0];
    let newContent = template.replace(/^---\n[\s\S]*?\n---\n/, frontmatter);
    await this.app.vault.modify(file, newContent);
  }
  async updateNpcFile(file, content) {
    await this.updateTemplateBasedFile(file, content, NPC_TEMPLATE);
  }
  async updatePcFile(file, content) {
    await this.updateTemplateBasedFile(file, content, PC_TEMPLATE);
  }
  async updateAdventureFile(file, content) {
    await this.updateTemplateBasedFile(file, content, ADVENTURE_TEMPLATE);
  }
  async updateSessionFile(file, content) {
    const roleMatch = content.match(/role:\s*(.+)/);
    const role = roleMatch ? roleMatch[1].trim() : "gm";
    const template = role === "player" ? SESSION_PLAYER_TEMPLATE : SESSION_GM_TEMPLATE;
    await this.updateTemplateBasedFile(file, content, template);
  }
  async updateFactionFile(file, content) {
    await this.updateTemplateBasedFile(file, content, FACTION_TEMPLATE);
  }
  async updateItemFile(file, content) {
    await this.updateTemplateBasedFile(file, content, ITEM_TEMPLATE);
  }
  async updateSpellFile(file, content) {
    await this.updateTemplateBasedFile(file, content, SPELL_TEMPLATE);
  }
  /**
   * Check if the vault has been initialized with the required folder structure
   */
  isVaultInitialized() {
    const requiredFolders = [
      "z_Templates",
      "z_Assets",
      "z_Beastiarity",
      "z_Databases",
      "z_Dataviews",
      "z_Daten",
      "z_Decks",
      "z_Log",
      "z_Scripts",
      "z_SessionTranscripts",
      "z_Tables",
      "ttrpgs"
    ];
    return requiredFolders.every((folder) => {
      const folderExists = this.app.vault.getAbstractFileByPath(folder);
      return folderExists instanceof import_obsidian.TFolder;
    });
  }
  /**
   * Purge all D&D Campaign Hub files and folders from the vault
   */
  async purgeVault() {
    const foldersToRemove = [
      "z_Templates",
      "z_Assets",
      "z_Beastiarity",
      "z_Databases",
      "z_Dataviews",
      "z_Daten",
      "z_Decks",
      "z_Log",
      "z_Scripts",
      "z_SessionTranscripts",
      "z_Tables",
      "ttrpgs"
    ];
    let removedCount = 0;
    let errors = [];
    for (const folderPath of foldersToRemove) {
      try {
        const folder = this.app.vault.getAbstractFileByPath(folderPath);
        if (folder instanceof import_obsidian.TFolder) {
          await this.app.vault.delete(folder, true);
          removedCount++;
        }
      } catch (error) {
        errors.push(`${folderPath}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    if (errors.length > 0) {
      new import_obsidian.Notice(`Purge completed with errors. Removed ${removedCount} folders. Errors: ${errors.join(", ")}`);
    } else {
      new import_obsidian.Notice(`Successfully purged ${removedCount} D&D Campaign Hub folders.`);
    }
  }
  /**
   * Install required community plugins
   */
  async installRequiredPlugins() {
    const requiredPlugins = [
      {
        id: "buttons",
        name: "Buttons",
        repo: "shabegom/buttons",
        version: "0.5.1"
      },
      {
        id: "dataview",
        name: "Dataview",
        repo: "blacksmithgu/obsidian-dataview",
        version: "0.5.68"
      },
      {
        id: "calendarium",
        name: "Calendarium",
        repo: "javalent/calendarium",
        version: "2.1.0"
      }
    ];
    new import_obsidian.Notice("Installing required plugins...");
    for (const plugin of requiredPlugins) {
      try {
        await this.installPlugin(plugin);
      } catch (error) {
        console.error(`Failed to install ${plugin.name}:`, error);
        new import_obsidian.Notice(`Failed to install ${plugin.name}. Please install manually.`);
      }
    }
    await this.enablePlugins(requiredPlugins.map((p) => p.id));
    new import_obsidian.Notice("Required plugins installed! Reloading...");
    setTimeout(() => {
      this.app.commands.executeCommandById("app:reload");
    }, 1500);
  }
  /**
   * Install a single plugin from GitHub
   */
  async installPlugin(plugin) {
    const adapter = this.app.vault.adapter;
    const pluginsFolder = `.obsidian/plugins`;
    const pluginPath = `${pluginsFolder}/${plugin.id}`;
    const exists = await adapter.exists(pluginPath);
    if (exists) {
      console.log(`Plugin ${plugin.name} already installed`);
      return;
    }
    await adapter.mkdir(pluginPath);
    const manifestUrl = `https://raw.githubusercontent.com/${plugin.repo}/HEAD/manifest.json`;
    const manifestResponse = await (0, import_obsidian.requestUrl)({ url: manifestUrl });
    const manifest = manifestResponse.text;
    await adapter.write(`${pluginPath}/manifest.json`, manifest);
    const mainUrl = `https://github.com/${plugin.repo}/releases/download/${plugin.version}/main.js`;
    const mainResponse = await (0, import_obsidian.requestUrl)({
      url: mainUrl,
      method: "GET"
    });
    const mainJsArray = new Uint8Array(mainResponse.arrayBuffer);
    await adapter.writeBinary(`${pluginPath}/main.js`, mainJsArray);
    try {
      const stylesUrl = `https://github.com/${plugin.repo}/releases/download/${plugin.version}/styles.css`;
      const stylesResponse = await (0, import_obsidian.requestUrl)({ url: stylesUrl });
      await adapter.write(`${pluginPath}/styles.css`, stylesResponse.text);
    } catch (error) {
    }
    console.log(`Installed plugin: ${plugin.name}`);
  }
  /**
   * Enable plugins in community-plugins.json
   */
  async enablePlugins(pluginIds) {
    const adapter = this.app.vault.adapter;
    const configPath = `.obsidian/community-plugins.json`;
    let enabledPlugins = [];
    const exists = await adapter.exists(configPath);
    if (exists) {
      const content = await adapter.read(configPath);
      enabledPlugins = JSON.parse(content);
    }
    for (const id of pluginIds) {
      if (!enabledPlugins.includes(id)) {
        enabledPlugins.push(id);
      }
    }
    await adapter.write(configPath, JSON.stringify(enabledPlugins, null, 2));
  }
  /**
   * Check if required dependencies are installed
   */
  async checkDependencies() {
    var _a, _b;
    const requiredPlugins = [
      { id: "buttons", name: "Buttons" },
      { id: "dataview", name: "Dataview" },
      { id: "calendarium", name: "Calendarium" }
    ];
    const installed = [];
    const missing = [];
    const enabledPlugins = (_b = (_a = this.app.plugins) == null ? void 0 : _a.enabledPlugins) != null ? _b : /* @__PURE__ */ new Set();
    for (const plugin of requiredPlugins) {
      if (enabledPlugins.has(plugin.id)) {
        installed.push(plugin.name);
      } else {
        missing.push(plugin.name);
      }
    }
    return { missing, installed };
  }
  /**
   * Show dependency status to user. Returns dependency summary for caller reuse.
   */
  async showDependencyModal(force = false, silentWhenSatisfied = false) {
    const deps = await this.checkDependencies();
    if (deps.missing.length > 0 || force) {
      new DependencyModal(this.app, deps).open();
    } else if (!silentWhenSatisfied) {
      new import_obsidian.Notice("All required D&D Campaign Hub plugins are already installed.");
    }
    return deps;
  }
  /**
   * Initialize the vault with the required folder structure and templates
   */
  async initializeVault() {
    new import_obsidian.Notice("Initializing D&D Campaign Hub vault structure...");
    await this.installRequiredPlugins();
    const deps = await this.showDependencyModal(false, true);
    if (deps.missing.length > 0) {
      return;
    }
    const foldersToCreate = [
      "z_Templates",
      "z_Assets",
      "z_Beastiarity",
      "z_Databases",
      "z_Dataviews",
      "z_Daten",
      "z_Decks",
      "z_Log",
      "z_Scripts",
      "z_SessionTranscripts",
      "z_Tables",
      "z_Backups",
      "ttrpgs"
    ];
    for (const folder of foldersToCreate) {
      try {
        await this.app.vault.createFolder(folder);
      } catch (error) {
      }
    }
    await this.createTemplateFiles();
    await this.configurePluginSettings();
    new import_obsidian.Notice("Vault initialized successfully! Please reload Obsidian (Ctrl+R) to activate plugins.");
  }
  /**
   * Create template files in z_Templates folder
   */
  async createTemplateFiles() {
    const templates = {
      "z_Templates/world.md": WORLD_TEMPLATE,
      "z_Templates/session-gm.md": SESSION_GM_TEMPLATE,
      "z_Templates/session-player.md": SESSION_PLAYER_TEMPLATE,
      "z_Templates/Frontmatter - NPC.md": NPC_TEMPLATE,
      "z_Templates/Frontmatter - Player Character.md": PC_TEMPLATE,
      "z_Templates/Frontmatter - Adventure.md": ADVENTURE_TEMPLATE,
      "z_Templates/Frontmatter - Faction.md": FACTION_TEMPLATE,
      "z_Templates/Frontmatter - Item.md": ITEM_TEMPLATE,
      "z_Templates/Frontmatter - Spell.md": SPELL_TEMPLATE
    };
    for (const [path, content] of Object.entries(templates)) {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile instanceof import_obsidian.TFile) {
          await this.app.vault.modify(existingFile, content);
        } else {
          await this.app.vault.create(path, content);
        }
      } catch (error) {
        console.error(`Failed to create/update template ${path}:`, error);
      }
    }
  }
  /**
   * Configure settings for integrated plugins
   */
  async configurePluginSettings() {
    try {
      const templaterSettings = {
        templates_folder: "z_Templates",
        user_scripts_folder: "z_Scripts",
        trigger_on_file_creation: true,
        enable_folder_templates: true,
        folder_templates: [
          {
            folder: "ttrpgs",
            template: "z_Templates/world.md"
          }
        ]
      };
      console.log("D&D Campaign Hub: Suggested Templater settings:", templaterSettings);
    } catch (error) {
      console.error("Failed to configure Templater:", error);
    }
    try {
      const hideFoldersSettings = {
        attachmentFolderNames: ["startsWith::z_"],
        matchCaseInsensitive: true
      };
      console.log("D&D Campaign Hub: Suggested Hide Folders settings:", hideFoldersSettings);
    } catch (error) {
      console.error("Failed to configure Hide Folders:", error);
    }
  }
  async createCampaign() {
    new CampaignCreationModal(this.app, this).open();
  }
  async createNpc() {
    const npcName = await this.promptForName("NPC");
    if (!npcName) return;
    const npcPath = `${this.settings.currentCampaign}/NPCs/${npcName}`;
    await this.ensureFolderExists(npcPath);
    const template = this.settings.defaultTemplates.npc || this.getDefaultNpcTemplate();
    const filePath = `${npcPath}/${npcName}.md`;
    await this.app.vault.create(filePath, template);
    await this.app.workspace.openLinkText(filePath, "", true);
    new import_obsidian.Notice(`NPC "${npcName}" created!`);
  }
  async createPc() {
    const pcName = await this.promptForName("Player Character");
    if (!pcName) return;
    const pcPath = `${this.settings.currentCampaign}/PCs/${pcName}`;
    await this.ensureFolderExists(pcPath);
    const template = this.settings.defaultTemplates.pc || this.getDefaultPcTemplate();
    const filePath = `${pcPath}/${pcName}.md`;
    await this.app.vault.create(filePath, template);
    await this.app.workspace.openLinkText(filePath, "", true);
    new import_obsidian.Notice(`Player Character "${pcName}" created!`);
  }
  async createAdventure() {
    const adventureName = await this.promptForName("Adventure");
    if (!adventureName) return;
    const adventurePath = `${this.settings.currentCampaign}/Adventures/${adventureName}`;
    await this.ensureFolderExists(adventurePath);
    const template = this.settings.defaultTemplates.adventure || this.getDefaultAdventureTemplate();
    const filePath = `${adventurePath}/${adventureName}.md`;
    await this.app.vault.create(filePath, template);
    await this.app.workspace.openLinkText(filePath, "", true);
    new import_obsidian.Notice(`Adventure "${adventureName}" created!`);
  }
  async createSession() {
    new SessionCreationModal(this.app, this).open();
  }
  async createItem() {
    const itemName = await this.promptForName("Item");
    if (!itemName) return;
    const itemPath = `${this.settings.currentCampaign}/Items/${itemName}`;
    await this.ensureFolderExists(itemPath);
    const template = this.settings.defaultTemplates.item || this.getDefaultItemTemplate();
    const filePath = `${itemPath}/${itemName}.md`;
    await this.app.vault.create(filePath, template);
    await this.app.workspace.openLinkText(filePath, "", true);
    new import_obsidian.Notice(`Item "${itemName}" created!`);
  }
  async createSpell() {
    const spellName = await this.promptForName("Spell");
    if (!spellName) return;
    const spellPath = `${this.settings.currentCampaign}/Spells/${spellName}`;
    await this.ensureFolderExists(spellPath);
    const template = this.settings.defaultTemplates.spell || this.getDefaultSpellTemplate();
    const filePath = `${spellPath}/${spellName}.md`;
    await this.app.vault.create(filePath, template);
    await this.app.workspace.openLinkText(filePath, "", true);
    new import_obsidian.Notice(`Spell "${spellName}" created!`);
  }
  async createFaction() {
    const factionName = await this.promptForName("Faction");
    if (!factionName) return;
    const factionPath = `${this.settings.currentCampaign}/Factions/${factionName}`;
    await this.ensureFolderExists(factionPath);
    const template = this.settings.defaultTemplates.faction || this.getDefaultFactionTemplate();
    const filePath = `${factionPath}/${factionName}.md`;
    await this.app.vault.create(filePath, template);
    await this.app.workspace.openLinkText(filePath, "", true);
    new import_obsidian.Notice(`Faction "${factionName}" created!`);
  }
  async promptForName(type) {
    return new Promise((resolve) => {
      const modal = new NamePromptModal(this.app, type, resolve);
      modal.open();
    });
  }
  async ensureFolderExists(path) {
    const folders = path.split("/");
    let currentPath = "";
    for (const folder of folders) {
      currentPath += (currentPath ? "/" : "") + folder;
      try {
        await this.app.vault.createFolder(currentPath);
      } catch (error) {
      }
    }
  }
  getDefaultCampaignTemplate() {
    return CAMPAIGN_TEMPLATE;
  }
  getDefaultNpcTemplate() {
    return NPC_TEMPLATE;
  }
  getDefaultPcTemplate() {
    return PC_TEMPLATE;
  }
  getDefaultAdventureTemplate() {
    return ADVENTURE_TEMPLATE;
  }
  getDefaultSessionTemplate() {
    return SESSION_DEFAULT_TEMPLATE;
  }
  getDefaultItemTemplate() {
    return ITEM_TEMPLATE;
  }
  getDefaultSpellTemplate() {
    return SPELL_TEMPLATE;
  }
  getDefaultFactionTemplate() {
    return FACTION_TEMPLATE;
  }
  getFileNameFromPath() {
    return "New Entity";
  }
};
var DndCampaignHubSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    new import_obsidian.Setting(containerEl).setName("D&D Vault Path").setDesc("Path to your D&D vault (relative to Obsidian vault root)").addText(
      (text) => text.setPlaceholder("My Vault").setValue(this.plugin.settings.vaultPath).onChange(async (value) => {
        this.plugin.settings.vaultPath = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Current Campaign").setDesc("Path to the current active campaign (relative to vault root)").addText(
      (text) => text.setPlaceholder("ttrpgs/Campaign Name").setValue(this.plugin.settings.currentCampaign).onChange(async (value) => {
        this.plugin.settings.currentCampaign = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Hotkey").setDesc("Hotkey to open the D&D Hub (currently Ctrl+Shift+M)").addText(
      (text) => text.setPlaceholder("Ctrl+Shift+M").setValue(this.plugin.settings.hotkey).onChange(async (value) => {
        this.plugin.settings.hotkey = value;
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h3", { text: "Default Templates" });
    new import_obsidian.Setting(containerEl).setName("Campaign Template").setDesc("Default template for new campaigns").addTextArea(
      (text) => text.setPlaceholder("Enter campaign template...").setValue(this.plugin.settings.defaultTemplates.campaign).onChange(async (value) => {
        this.plugin.settings.defaultTemplates.campaign = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("NPC Template").setDesc("Default template for new NPCs").addTextArea(
      (text) => text.setPlaceholder("Enter NPC template...").setValue(this.plugin.settings.defaultTemplates.npc).onChange(async (value) => {
        this.plugin.settings.defaultTemplates.npc = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("PC Template").setDesc("Default template for new player characters").addTextArea(
      (text) => text.setPlaceholder("Enter PC template...").setValue(this.plugin.settings.defaultTemplates.pc).onChange(async (value) => {
        this.plugin.settings.defaultTemplates.pc = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Adventure Template").setDesc("Default template for new adventures").addTextArea(
      (text) => text.setPlaceholder("Enter adventure template...").setValue(this.plugin.settings.defaultTemplates.adventure).onChange(async (value) => {
        this.plugin.settings.defaultTemplates.adventure = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Session Template").setDesc("Default template for new sessions").addTextArea(
      (text) => text.setPlaceholder("Enter session template...").setValue(this.plugin.settings.defaultTemplates.session).onChange(async (value) => {
        this.plugin.settings.defaultTemplates.session = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Item Template").setDesc("Default template for new items").addTextArea(
      (text) => text.setPlaceholder("Enter item template...").setValue(this.plugin.settings.defaultTemplates.item).onChange(async (value) => {
        this.plugin.settings.defaultTemplates.item = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Spell Template").setDesc("Default template for new spells").addTextArea(
      (text) => text.setPlaceholder("Enter spell template...").setValue(this.plugin.settings.defaultTemplates.spell).onChange(async (value) => {
        this.plugin.settings.defaultTemplates.spell = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Faction Template").setDesc("Default template for new factions").addTextArea(
      (text) => text.setPlaceholder("Enter faction template...").setValue(this.plugin.settings.defaultTemplates.faction).onChange(async (value) => {
        this.plugin.settings.defaultTemplates.faction = value;
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h3", { text: "Danger Zone" });
    new import_obsidian.Setting(containerEl).setName("Purge D&D Campaign Hub").setDesc("\u26A0\uFE0F Remove all D&D Campaign Hub folders and files from this vault. This cannot be undone!").addButton(
      (button) => button.setButtonText("Purge Vault").setWarning().onClick(async () => {
        new PurgeConfirmModal(this.app, this.plugin).open();
      })
    );
  }
};
var UpdateConfirmModal = class extends import_obsidian.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "\u{1F504} Update D&D Hub Templates" });
    contentEl.createEl("p", {
      text: "This will update all template files and existing campaign World.md files with the latest version."
    });
    contentEl.createEl("h3", { text: "What will be updated:" });
    const updateList = contentEl.createEl("ul");
    updateList.createEl("li", { text: "Template files in z_Templates/" });
    updateList.createEl("li", { text: "All campaign World.md files (buttons, dataviews, structure)" });
    contentEl.createEl("h3", { text: "What will be preserved:" });
    const preserveList = contentEl.createEl("ul");
    preserveList.createEl("li", { text: "\u2705 Campaign frontmatter (name, dates, calendar settings)" });
    preserveList.createEl("li", { text: "\u2705 User-written content in 'Truths about the campaign/world'" });
    preserveList.createEl("li", { text: "\u2705 All NPCs, PCs, sessions, and other campaign files" });
    contentEl.createEl("h3", { text: "\u26A0\uFE0F Important:" });
    const warningList = contentEl.createEl("ul", { cls: "mod-warning" });
    warningList.createEl("li", { text: "Automatic backups will be created in z_Backups/" });
    warningList.createEl("li", { text: "Template updates may require manual cleanup if you heavily customized your files" });
    warningList.createEl("li", { text: "Review the updated files after the process completes" });
    const buttonContainer = contentEl.createDiv({ cls: "modal-button-container" });
    const cancelBtn = buttonContainer.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => {
      this.close();
    });
    const confirmBtn = buttonContainer.createEl("button", {
      text: "Update Templates",
      cls: "mod-cta"
    });
    confirmBtn.addEventListener("click", async () => {
      this.close();
      await this.plugin.performTemplateUpdate();
    });
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var PurgeConfirmModal = class extends import_obsidian.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "\u26A0\uFE0F Purge D&D Campaign Hub" });
    contentEl.createEl("p", {
      text: "This will permanently delete ALL D&D Campaign Hub folders and their contents:",
      cls: "mod-warning"
    });
    const list = contentEl.createEl("ul");
    const folders = [
      "ttrpgs/ - All campaigns and their content",
      "z_Templates/ - All template files",
      "z_Assets/ - All assets",
      "z_Beastiarity/ - All monster data",
      "z_Databases/ - All databases",
      "z_Log/ - All session logs",
      "z_Tables/ - All tables",
      "And all other z_* folders"
    ];
    folders.forEach((folder) => {
      list.createEl("li", { text: folder });
    });
    contentEl.createEl("p", {
      text: "\u26A0\uFE0F THIS CANNOT BE UNDONE!",
      cls: "mod-warning"
    });
    contentEl.createEl("p", {
      text: "Type 'PURGE' to confirm:"
    });
    const input = contentEl.createEl("input", {
      type: "text",
      placeholder: "Type PURGE to confirm"
    });
    const buttonContainer = contentEl.createDiv({ cls: "dnd-modal-buttons" });
    const cancelButton = buttonContainer.createEl("button", { text: "Cancel" });
    cancelButton.addEventListener("click", () => {
      this.close();
    });
    const purgeButton = buttonContainer.createEl("button", {
      text: "Purge Vault",
      cls: "mod-warning"
    });
    purgeButton.disabled = true;
    input.addEventListener("input", () => {
      purgeButton.disabled = input.value !== "PURGE";
    });
    purgeButton.addEventListener("click", async () => {
      if (input.value === "PURGE") {
        this.close();
        await this.plugin.purgeVault();
      }
    });
    input.focus();
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var DndHubModal = class _DndHubModal extends import_obsidian.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  showInitializationUI(container) {
    container.createEl("p", {
      text: "Welcome to D&D Campaign Hub! Your vault needs to be initialized before you can start creating campaigns.",
      cls: "dnd-hub-info"
    });
    container.createEl("p", {
      text: "This will create the following structure:"
    });
    const list = container.createEl("ul");
    const folders = [
      "ttrpgs/ - Main folder for all campaigns",
      "z_Templates/ - Template files for campaigns, sessions, NPCs, etc.",
      "z_Assets/ - Images and other assets",
      "z_Beastiarity/ - Monster and creature stats",
      "z_Databases/ - Campaign databases",
      "z_Log/ - Session logs",
      "z_Tables/ - Random tables and generators",
      "And more supporting folders..."
    ];
    folders.forEach((folder) => {
      list.createEl("li", { text: folder });
    });
    container.createEl("p", {
      text: "\u26A0\uFE0F Note: This will also configure settings for Templater and Hide Folders plugins if they are installed."
    });
    const buttonContainer = container.createDiv({ cls: "dnd-hub-init-buttons" });
    const initButton = buttonContainer.createEl("button", {
      text: "\u{1F3B2} Initialize Vault",
      cls: "mod-cta"
    });
    initButton.addEventListener("click", async () => {
      this.close();
      await this.plugin.initializeVault();
      new _DndHubModal(this.app, this.plugin).open();
    });
    const cancelButton = buttonContainer.createEl("button", {
      text: "Cancel"
    });
    cancelButton.addEventListener("click", () => {
      this.close();
    });
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h1", { text: "D&D Campaign Hub" });
    if (!this.plugin.isVaultInitialized()) {
      this.showInitializationUI(contentEl);
      return;
    }
    contentEl.createEl("h2", { text: "Quick Actions" });
    const quickActionsContainer = contentEl.createDiv({ cls: "dnd-hub-quick-actions" });
    this.createActionButton(quickActionsContainer, "\u{1F3B2} New Campaign", () => {
      this.close();
      this.plugin.createCampaign();
    });
    this.createActionButton(quickActionsContainer, "\u{1F4DC} New Session", () => {
      this.close();
      this.plugin.createSession();
    });
    contentEl.createEl("p", {
      text: "NPCs, PCs, adventures, and more builders are coming soon.",
      cls: "dnd-hub-info"
    });
  }
  createActionButton(container, text, callback) {
    const button = container.createEl("button", { text, cls: "dnd-hub-button" });
    button.addEventListener("click", callback);
  }
  createBrowseButton(container, text, folderName) {
    const button = container.createEl("button", { text, cls: "dnd-hub-button" });
    button.addEventListener("click", () => {
      this.close();
      this.browseFolder(folderName);
    });
  }
  async browseFolder(folderName) {
    let folderPath;
    if (["NPCs", "PCs", "Adventures", "Factions", "Items"].includes(folderName)) {
      folderPath = `${this.plugin.settings.currentCampaign}/${folderName}`;
    } else if (folderName === "Campaigns") {
      folderPath = "ttrpgs";
    } else if (folderName === "Sessions") {
      folderPath = this.plugin.settings.currentCampaign;
    } else {
      folderPath = folderName;
    }
    try {
      const folder = this.app.vault.getAbstractFileByPath(folderPath);
      if (folder instanceof import_obsidian.TFolder) {
        const leaf = this.app.workspace.getLeaf();
        await this.app.workspace.revealLeaf(leaf);
      } else {
        new import_obsidian.Notice(`Folder "${folderName}" not found. Create some ${folderName.toLowerCase()} first!`);
      }
    } catch (error) {
      new import_obsidian.Notice(`Error browsing ${folderName}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var NamePromptModal = class extends import_obsidian.Modal {
  constructor(app, type, resolve) {
    super(app);
    this.type = type;
    this.resolve = resolve;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: `Create New ${this.type}` });
    const input = contentEl.createEl("input", {
      type: "text",
      placeholder: `Enter ${this.type.toLowerCase()} name...`
    });
    const buttonContainer = contentEl.createDiv({ cls: "dnd-modal-buttons" });
    const cancelButton = buttonContainer.createEl("button", { text: "Cancel" });
    cancelButton.addEventListener("click", () => {
      this.close();
      this.resolve(null);
    });
    const createButton = buttonContainer.createEl("button", {
      text: "Create",
      cls: "mod-cta"
    });
    createButton.addEventListener("click", () => {
      const name = input.value.trim();
      if (name) {
        this.close();
        this.resolve(name);
      }
    });
    input.focus();
    input.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        createButton.click();
      }
    });
  }
  onClose() {
    this.resolve(null);
  }
};
var SessionCreationModal = class extends import_obsidian.Modal {
  constructor(app, plugin) {
    super(app);
    this.sessionTitle = "";
    this.location = "";
    this.useCustomDate = false;
    this.calendar = "";
    this.startYear = "";
    this.startMonth = "";
    this.startDay = "";
    this.endYear = "";
    this.endMonth = "";
    this.endDay = "";
    this.selectedCalendarData = null;
    this.endDayDropdown = null;
    this.plugin = plugin;
    this.sessionDate = (/* @__PURE__ */ new Date()).toISOString().split("T")[0] || "";
  }
  async loadCalendarData() {
    var _a, _b, _c;
    const campaignPath = this.plugin.settings.currentCampaign;
    const worldFile = this.app.vault.getAbstractFileByPath(`${campaignPath}/World.md`);
    if (worldFile instanceof import_obsidian.TFile) {
      const worldContent = await this.app.vault.read(worldFile);
      const calendarMatch = worldContent.match(/fc-calendar:\s*(.+)/);
      if (calendarMatch && calendarMatch[1]) {
        this.calendar = calendarMatch[1].trim();
        const calendariumPlugin = (_b = (_a = this.app.plugins) == null ? void 0 : _a.plugins) == null ? void 0 : _b.calendarium;
        if (calendariumPlugin && ((_c = calendariumPlugin.data) == null ? void 0 : _c.calendars)) {
          const calendars = calendariumPlugin.data.calendars;
          for (const [id, calData] of Object.entries(calendars)) {
            if (calData.name === this.calendar) {
              this.selectedCalendarData = calData;
              break;
            }
          }
        }
      }
    }
    const previousSession = await this.getPreviousSession();
    if (previousSession) {
      this.startYear = previousSession.endYear;
      this.startMonth = previousSession.endMonth;
      this.startDay = previousSession.endDay;
    } else {
      if (worldFile instanceof import_obsidian.TFile) {
        const worldContent = await this.app.vault.read(worldFile);
        const yearMatch = worldContent.match(/fc-date:\s*\n\s*year:\s*(.+)/);
        const monthMatch = worldContent.match(/fc-date:\s*\n\s*year:.*\n\s*month:\s*(.+)/);
        const dayMatch = worldContent.match(/fc-date:\s*\n\s*year:.*\n\s*month:.*\n\s*day:\s*(.+)/);
        if (yearMatch && yearMatch[1]) this.startYear = yearMatch[1].trim();
        if (monthMatch && monthMatch[1]) this.startMonth = monthMatch[1].trim();
        if (dayMatch && dayMatch[1]) this.startDay = dayMatch[1].trim();
      }
    }
    if (!this.startYear) this.startYear = "1";
    if (!this.startMonth) this.startMonth = "1";
    if (!this.startDay) this.startDay = "1";
    this.endYear = this.startYear;
    this.endMonth = this.startMonth;
    this.endDay = this.startDay;
  }
  async getPreviousSession() {
    const campaignFolder = this.app.vault.getAbstractFileByPath(this.plugin.settings.currentCampaign);
    if (campaignFolder instanceof import_obsidian.TFolder) {
      const files = campaignFolder.children.filter(
        (f) => f instanceof import_obsidian.TFile && f.name.match(/^\d{3}_\d{8}\.md$/)
      );
      if (files.length === 0) return null;
      const sortedFiles = files.sort((a, b) => {
        const numA = parseInt(a.name.substring(0, 3));
        const numB = parseInt(b.name.substring(0, 3));
        return numB - numA;
      });
      const lastSession = sortedFiles[0];
      const content = await this.app.vault.read(lastSession);
      const endYearMatch = content.match(/fc-end:\s*\n\s*year:\s*(.+)/);
      const endMonthMatch = content.match(/fc-end:\s*\n\s*year:.*\n\s*month:\s*(.+)/);
      const endDayMatch = content.match(/fc-end:\s*\n\s*year:.*\n\s*month:.*\n\s*day:\s*(.+)/);
      if ((endYearMatch == null ? void 0 : endYearMatch[1]) && (endMonthMatch == null ? void 0 : endMonthMatch[1]) && (endDayMatch == null ? void 0 : endDayMatch[1])) {
        return {
          endYear: endYearMatch[1].trim(),
          endMonth: endMonthMatch[1].trim(),
          endDay: endDayMatch[1].trim()
        };
      }
    }
    return null;
  }
  async onOpen() {
    var _a;
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "\u{1F4DC} Create New Session" });
    await this.loadCalendarData();
    const campaignPath = this.plugin.settings.currentCampaign;
    const campaignName = (campaignPath == null ? void 0 : campaignPath.split("/").pop()) || "Unknown";
    contentEl.createEl("p", {
      text: `Campaign: ${campaignName}`,
      cls: "setting-item-description"
    });
    const nextSessionNum = this.getNextSessionNumber();
    contentEl.createEl("p", {
      text: `Session Number: ${nextSessionNum}`,
      cls: "setting-item-description"
    });
    new import_obsidian.Setting(contentEl).setName("Session Title").setDesc("Optional descriptive title for this session").addText((text) => {
      text.setPlaceholder("e.g., The Goblin Ambush").onChange((value) => {
        this.sessionTitle = value;
      });
      text.inputEl.focus();
    });
    new import_obsidian.Setting(contentEl).setName("Session Date").setDesc("Date when this session was/will be played (real world)").addText(
      (text) => text.setValue(this.sessionDate).onChange((value) => {
        this.sessionDate = value;
      })
    ).addToggle(
      (toggle) => toggle.setTooltip("Use custom date").setValue(this.useCustomDate).onChange((value) => {
        this.useCustomDate = value;
        if (!value) {
          this.sessionDate = (/* @__PURE__ */ new Date()).toISOString().split("T")[0] || "";
        }
      })
    );
    if (this.calendar && this.selectedCalendarData) {
      contentEl.createEl("h3", { text: `\u{1F4C5} In-Game Calendar: ${this.selectedCalendarData.name || this.calendar}` });
      const monthData = ((_a = this.selectedCalendarData.static) == null ? void 0 : _a.months) || [];
      new import_obsidian.Setting(contentEl).setName("Start Date (In-Game)").setDesc(`Starts: ${this.getDateDisplay(this.startYear, this.startMonth, this.startDay, monthData)}`);
      const endDateSetting = new import_obsidian.Setting(contentEl).setName("End Date (In-Game)").setDesc("When does this session end in your world?");
      const endDateDisplay = contentEl.createEl("div", {
        cls: "dnd-date-display",
        text: this.getDateDisplay(this.endYear, this.endMonth, this.endDay, monthData)
      });
      endDateSetting.addButton((button) => {
        button.setButtonText("\u{1F4C5} Pick End Date").setCta().onClick(async () => {
          await this.openSessionDatePicker(endDateDisplay, monthData);
        });
      });
    }
    new import_obsidian.Setting(contentEl).setName("Location").setDesc("Where does this session take place in your world?").addText(
      (text) => text.setPlaceholder("e.g., Phandalin").onChange((value) => {
        this.location = value;
      })
    );
    const buttonContainer = contentEl.createDiv({ cls: "dnd-modal-buttons" });
    const cancelButton = buttonContainer.createEl("button", { text: "Cancel" });
    cancelButton.addEventListener("click", () => {
      this.close();
    });
    const createButton = buttonContainer.createEl("button", {
      text: "Create Session",
      cls: "mod-cta"
    });
    createButton.addEventListener("click", async () => {
      this.close();
      await this.createSessionFile();
    });
  }
  getNextSessionNumber() {
    const campaignFolder = this.app.vault.getAbstractFileByPath(this.plugin.settings.currentCampaign);
    let nextNumber = 1;
    if (campaignFolder instanceof import_obsidian.TFolder) {
      const files = campaignFolder.children.filter(
        (f) => f instanceof import_obsidian.TFile && f.name.match(/^\d{3}_\d{8}\.md$/)
      );
      const numbers = files.map((f) => parseInt(f.name.substring(0, 3)));
      if (numbers.length > 0) {
        nextNumber = Math.max(...numbers) + 1;
      }
    }
    return nextNumber;
  }
  getDateDisplay(year, month, day, monthData) {
    var _a;
    const monthIndex = parseInt(month) - 1;
    const monthName = ((_a = monthData[monthIndex]) == null ? void 0 : _a.name) || `Month ${month}`;
    return `${monthName} ${day}, Year ${year}`;
  }
  async openSessionDatePicker(displayElement, monthData) {
    const modal = new CalendarDateInputModal(
      this.app,
      this.selectedCalendarData,
      this.endYear,
      this.endMonth,
      this.endDay,
      (year, month, day) => {
        this.endYear = year;
        this.endMonth = month;
        this.endDay = day;
        displayElement.setText(this.getDateDisplay(this.endYear, this.endMonth, this.endDay, monthData));
      }
    );
    modal.open();
  }
  async createSessionFile() {
    const campaignPath = this.plugin.settings.currentCampaign;
    const campaignName = (campaignPath == null ? void 0 : campaignPath.split("/").pop()) || "Unknown";
    const nextNumber = this.getNextSessionNumber();
    new import_obsidian.Notice(`Creating session ${nextNumber}...`);
    try {
      const worldFile = this.app.vault.getAbstractFileByPath(`${campaignPath}/World.md`);
      let isGM = true;
      if (worldFile instanceof import_obsidian.TFile) {
        const worldContent = await this.app.vault.read(worldFile);
        const roleMatch = worldContent.match(/role:\s*(GM|player)/i);
        if (roleMatch && roleMatch[1]) {
          isGM = roleMatch[1].toLowerCase() === "gm";
        }
      }
      const templatePath = isGM ? "z_Templates/session-gm.md" : "z_Templates/session-player.md";
      const templateFile = this.app.vault.getAbstractFileByPath(templatePath);
      let sessionContent;
      if (templateFile instanceof import_obsidian.TFile) {
        sessionContent = await this.app.vault.read(templateFile);
      } else {
        sessionContent = isGM ? SESSION_GM_TEMPLATE : SESSION_PLAYER_TEMPLATE;
      }
      const dateStr = this.sessionDate.replace(/-/g, "");
      const fileName = `${nextNumber.toString().padStart(3, "0")}_${dateStr}.md`;
      const filePath = `${campaignPath}/${fileName}`;
      sessionContent = sessionContent.replace(/campaign: $/m, `campaign: ${campaignName}`).replace(/world: $/m, `world: ${campaignName}`).replace(/sessionNum: $/m, `sessionNum: ${nextNumber}`).replace(/location: $/m, `location: ${this.location}`).replace(/date: $/m, `date: ${this.sessionDate}`).replace(/fc-calendar: $/m, `fc-calendar: ${this.calendar}`).replace(/# Session\s*$/m, `# Session ${nextNumber}${this.sessionTitle ? " - " + this.sessionTitle : ""}`);
      sessionContent = sessionContent.replace(/fc-date:\s*\n\s*year:\s*$/m, `fc-date:
  year: ${this.startYear}`).replace(/(fc-date:\s*\n\s*year:.*\n\s*)month:\s*$/m, `$1month: ${this.startMonth}`).replace(/(fc-date:\s*\n\s*year:.*\n\s*month:.*\n\s*)day:\s*$/m, `$1day: ${this.startDay}`);
      sessionContent = sessionContent.replace(/fc-end:\s*\n\s*year:\s*$/m, `fc-end:
  year: ${this.endYear}`).replace(/(fc-end:\s*\n\s*year:.*\n\s*)month:\s*$/m, `$1month: ${this.endMonth}`).replace(/(fc-end:\s*\n\s*year:.*\n\s*month:.*\n\s*)day:\s*$/m, `$1day: ${this.endDay}`);
      await this.app.vault.create(filePath, sessionContent);
      await this.app.workspace.openLinkText(filePath, "", true);
      new import_obsidian.Notice(`\u2705 Session ${nextNumber} created successfully!`);
    } catch (error) {
      new import_obsidian.Notice(`\u274C Error creating session: ${error instanceof Error ? error.message : String(error)}`);
      console.error("Session creation error:", error);
    }
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var CampaignCreationModal = class extends import_obsidian.Modal {
  constructor(app, plugin) {
    super(app);
    this.campaignName = "";
    this.dmName = "";
    this.system = "D&D 5e";
    this.role = "GM";
    this.calendar = "";
    this.calendarName = "";
    this.startYear = "";
    this.startMonth = "";
    this.startDay = "";
    this.selectedCalendarData = null;
    this.calendarContainer = null;
    this.dayDropdown = null;
    this.plugin = plugin;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "\u{1F3B2} Create New Campaign" });
    new import_obsidian.Setting(contentEl).setName("Campaign Name").setDesc("The name of your campaign").addText((text) => {
      text.setPlaceholder("e.g., Lost Mines of Phandelver").onChange((value) => {
        this.campaignName = value;
      });
      text.inputEl.focus();
    });
    new import_obsidian.Setting(contentEl).setName("Your Role").setDesc("Are you the GM/DM or a player?").addDropdown((dropdown) => {
      dropdown.addOption("GM", "Game Master / DM").addOption("player", "Player").setValue(this.role).onChange((value) => {
        this.role = value;
        this.updateDMField();
      });
    });
    const dmSetting = new import_obsidian.Setting(contentEl).setName("DM Name").setDesc("Name of the Dungeon Master").addText(
      (text) => text.setPlaceholder("e.g., John Smith").onChange((value) => {
        this.dmName = value;
      })
    );
    if (this.role === "GM") {
      dmSetting.settingEl.style.display = "none";
    }
    new import_obsidian.Setting(contentEl).setName("Game System").setDesc("Which RPG system are you using?").addDropdown((dropdown) => {
      dropdown.addOption("D&D 5e", "Dungeons & Dragons 5th Edition").addOption("Pathfinder 2e", "Pathfinder 2nd Edition").addOption("Call of Cthulhu", "Call of Cthulhu").addOption("Savage Worlds", "Savage Worlds").addOption("FATE", "FATE Core").addOption("OSR", "Old School Renaissance").addOption("Other", "Other / Custom").setValue(this.system).onChange((value) => {
        this.system = value;
      });
    });
    contentEl.createEl("h3", { text: "\u{1F4C5} Calendar Settings" });
    const calendars = this.getAvailableCalendars();
    new import_obsidian.Setting(contentEl).setName("Fantasy Calendar").setDesc("Select an existing calendar or create a new one").addDropdown((dropdown) => {
      dropdown.addOption("", "None");
      dropdown.addOption("__CREATE_NEW__", "\u2795 Create New Calendar");
      calendars.forEach((cal) => {
        dropdown.addOption(cal.id, cal.name);
      });
      dropdown.setValue(this.calendar).onChange((value) => {
        var _a;
        this.calendar = value;
        if (value === "__CREATE_NEW__") {
          this.showCreateCalendarUI();
        } else if (value) {
          this.selectedCalendarData = this.getCalendarData(value);
          this.calendarName = ((_a = this.selectedCalendarData) == null ? void 0 : _a.name) || value;
          this.showDateSelectors();
        } else {
          this.hideDateSelectors();
        }
      });
    });
    this.calendarContainer = contentEl.createDiv({ cls: "dnd-calendar-container" });
    const buttonContainer = contentEl.createDiv({ cls: "dnd-modal-buttons" });
    const cancelButton = buttonContainer.createEl("button", { text: "Cancel" });
    cancelButton.addEventListener("click", () => {
      this.close();
    });
    const createButton = buttonContainer.createEl("button", {
      text: "Create Campaign",
      cls: "mod-cta"
    });
    createButton.addEventListener("click", async () => {
      if (!this.campaignName.trim()) {
        new import_obsidian.Notice("Please enter a campaign name!");
        return;
      }
      this.close();
      await this.createCampaignStructure();
    });
    this.updateDMField = () => {
      if (this.role === "GM") {
        dmSetting.settingEl.style.display = "none";
      } else {
        dmSetting.settingEl.style.display = "";
      }
    };
  }
  updateDMField() {
  }
  showDateSelectors() {
    if (!this.calendarContainer) return;
    this.calendarContainer.empty();
    if (!this.selectedCalendarData) return;
    if (!this.startYear) this.startYear = "1";
    if (!this.startMonth) this.startMonth = "1";
    if (!this.startDay) this.startDay = "1";
    const dateSetting = new import_obsidian.Setting(this.calendarContainer).setName("Campaign Start Date").setDesc("When does the campaign begin in your world?");
    const dateDisplay = this.calendarContainer.createEl("div", {
      cls: "dnd-date-display"
    });
    this.updateDateDisplay(dateDisplay);
    dateSetting.addButton((button) => {
      button.setButtonText("\u{1F4C5} Pick Date").setCta().onClick(async () => {
        await this.openCalendariumDatePicker();
      });
    });
  }
  updateDateDisplay(container) {
    var _a, _b, _c;
    const monthData = ((_b = (_a = this.selectedCalendarData) == null ? void 0 : _a.static) == null ? void 0 : _b.months) || [];
    const monthIndex = parseInt(this.startMonth || "1") - 1;
    const monthName = ((_c = monthData[monthIndex]) == null ? void 0 : _c.name) || `Month ${this.startMonth}`;
    container.setText(`${monthName} ${this.startDay}, Year ${this.startYear}`);
  }
  async openCalendariumDatePicker() {
    const modal = new CalendarDateInputModal(
      this.app,
      this.selectedCalendarData,
      this.startYear,
      this.startMonth,
      this.startDay,
      (year, month, day) => {
        var _a;
        this.startYear = year;
        this.startMonth = month;
        this.startDay = day;
        const dateDisplay = (_a = this.calendarContainer) == null ? void 0 : _a.querySelector(".dnd-date-display");
        if (dateDisplay) {
          this.updateDateDisplay(dateDisplay);
        }
      }
    );
    modal.open();
  }
  hideDateSelectors() {
    if (this.calendarContainer) {
      this.calendarContainer.empty();
    }
  }
  showCreateCalendarUI() {
    if (!this.calendarContainer) return;
    this.calendarContainer.empty();
    this.calendarContainer.createEl("p", {
      text: "Click below to open Calendarium's calendar creation interface.",
      cls: "setting-item-description"
    });
    const buttonContainer = this.calendarContainer.createDiv({ cls: "dnd-calendar-buttons" });
    const quickButton = buttonContainer.createEl("button", {
      text: "\u26A1 Quick Create",
      cls: "mod-cta"
    });
    quickButton.addEventListener("click", async () => {
      await this.openCalendariumCreation("quick");
    });
    const fullButton = buttonContainer.createEl("button", {
      text: "\u{1F3A8} Full Create"
    });
    fullButton.addEventListener("click", async () => {
      await this.openCalendariumCreation("full");
    });
    const importButton = buttonContainer.createEl("button", {
      text: "\u{1F4E5} Import"
    });
    importButton.addEventListener("click", async () => {
      await this.openCalendariumCreation("import");
    });
    this.calendarContainer.createEl("p", {
      text: "After creating your calendar, reopen this modal to select it.",
      cls: "setting-item-description mod-warning"
    });
  }
  async openCalendariumCreation(type) {
    var _a, _b;
    const calendariumPlugin = (_b = (_a = this.app.plugins) == null ? void 0 : _a.plugins) == null ? void 0 : _b.calendarium;
    if (!calendariumPlugin) {
      new import_obsidian.Notice("Calendarium plugin not found!");
      return;
    }
    this.close();
    const settingTab = this.app.setting;
    if (settingTab) {
      settingTab.open();
      settingTab.openTabById("calendarium");
    }
    const commands = {
      quick: "calendarium:open-quick-creator",
      full: "calendarium:open-creator",
      import: "calendarium:import-calendar"
    };
    const commandId = commands[type];
    setTimeout(() => {
      var _a2;
      (_a2 = this.app.commands) == null ? void 0 : _a2.executeCommandById(commandId);
    }, 100);
    new import_obsidian.Notice("After creating your calendar, use 'Create Campaign' again to select it.");
  }
  getAvailableCalendars() {
    var _a, _b, _c;
    const calendariumPlugin = (_b = (_a = this.app.plugins) == null ? void 0 : _a.plugins) == null ? void 0 : _b.calendarium;
    if (calendariumPlugin && ((_c = calendariumPlugin.data) == null ? void 0 : _c.calendars)) {
      const calendars = calendariumPlugin.data.calendars;
      return Object.keys(calendars).map((id) => ({
        id,
        name: calendars[id].name || id
      }));
    }
    return [];
  }
  getCalendarData(calendarId) {
    var _a, _b, _c;
    const calendariumPlugin = (_b = (_a = this.app.plugins) == null ? void 0 : _a.plugins) == null ? void 0 : _b.calendarium;
    if (calendariumPlugin && ((_c = calendariumPlugin.data) == null ? void 0 : _c.calendars)) {
      return calendariumPlugin.data.calendars[calendarId];
    }
    return null;
  }
  async createCampaignStructure() {
    const campaignName = this.campaignName.trim();
    const campaignPath = `ttrpgs/${campaignName}`;
    new import_obsidian.Notice(`Creating campaign "${campaignName}"...`);
    try {
      const campaignFolders = [
        campaignPath,
        `${campaignPath}/NPCs`,
        `${campaignPath}/PCs`,
        `${campaignPath}/Adventures`,
        `${campaignPath}/Factions`,
        `${campaignPath}/Items`,
        `${campaignPath}/Modules`,
        `${campaignPath}/Plot`,
        `${campaignPath}/fc-calendar`
      ];
      for (const folder of campaignFolders) {
        await this.plugin.ensureFolderExists(folder);
      }
      const worldTemplate = this.app.vault.getAbstractFileByPath("z_Templates/world.md");
      let worldContent;
      if (worldTemplate instanceof import_obsidian.TFile) {
        worldContent = await this.app.vault.read(worldTemplate);
      } else {
        worldContent = WORLD_TEMPLATE;
      }
      worldContent = worldContent.replace(/world: $/m, `world: ${campaignName}`).replace(/campaign: $/m, `campaign: ${campaignName}`).replace(/role: player$/m, `role: ${this.role}`).replace(/system:$/m, `system: ${this.system}`).replace(/fc-calendar: $/m, `fc-calendar: ${this.calendarName}`).replace(/fc-date:\s*\n\s*year:\s*$/m, `fc-date:
  year: ${this.startYear}`).replace(/(fc-date:\s*\n\s*year:.*\n\s*)month:\s*$/m, `$1month: ${this.startMonth}`).replace(/(fc-date:\s*\n\s*year:.*\n\s*month:.*\n\s*)day:\s*$/m, `$1day: ${this.startDay}`).replace(/# The World of Your Campaign/g, `# The World of ${campaignName}`).replace(/{{CAMPAIGN_NAME}}/g, campaignName);
      const worldFilePath = `${campaignPath}/World.md`;
      await this.app.vault.create(worldFilePath, worldContent);
      if (this.role === "GM") {
        const houseRulesContent = `---
type: rules
campaign: ${campaignName}
---

# House Rules

## Character Creation
- 

## Combat Rules
- 

## Homebrew Content
- 

## Table Etiquette
- 
`;
        await this.app.vault.create(`${campaignPath}/House Rules.md`, houseRulesContent);
      }
      this.plugin.settings.currentCampaign = campaignPath;
      await this.plugin.saveSettings();
      await this.app.workspace.openLinkText(worldFilePath, "", true);
      new import_obsidian.Notice(`\u2705 Campaign "${campaignName}" created successfully!`);
    } catch (error) {
      new import_obsidian.Notice(`\u274C Error creating campaign: ${error instanceof Error ? error.message : String(error)}`);
      console.error("Campaign creation error:", error);
    }
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var DependencyModal = class extends import_obsidian.Modal {
  constructor(app, dependencies) {
    super(app);
    this.dependencies = dependencies;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "\u26A0\uFE0F Missing Plugin Dependencies" });
    contentEl.createEl("p", {
      text: "D&D Campaign Hub requires the following community plugins to work properly:"
    });
    if (this.dependencies.missing.length > 0) {
      const missingList = contentEl.createEl("div", { cls: "dnd-dependency-list" });
      missingList.createEl("h3", { text: "\u274C Missing:" });
      const ul = missingList.createEl("ul");
      this.dependencies.missing.forEach((plugin) => {
        ul.createEl("li", { text: plugin });
      });
    }
    if (this.dependencies.installed.length > 0) {
      const installedList = contentEl.createEl("div", { cls: "dnd-dependency-list" });
      installedList.createEl("h3", { text: "\u2705 Installed:" });
      const ul = installedList.createEl("ul");
      this.dependencies.installed.forEach((plugin) => {
        ul.createEl("li", { text: plugin });
      });
    }
    contentEl.createEl("h3", { text: "\u{1F4E6} How to Install" });
    const instructions = contentEl.createEl("div", { cls: "dnd-dependency-instructions" });
    instructions.createEl("p", { text: "1. Open Settings \u2192 Community Plugins" });
    instructions.createEl("p", { text: "2. Click 'Browse' to open the plugin browser" });
    instructions.createEl("p", { text: "3. Search for and install the missing plugins" });
    instructions.createEl("p", { text: "4. Enable each plugin after installation" });
    instructions.createEl("p", { text: "5. Return to D&D Campaign Hub and try again" });
    contentEl.createEl("p", {
      text: "\u{1F4A1} These plugins add buttons, tables, and calendar features that make your campaigns interactive and organized.",
      cls: "dnd-dependency-note"
    });
    const buttonContainer = contentEl.createDiv({ cls: "dnd-modal-buttons" });
    const settingsButton = buttonContainer.createEl("button", {
      text: "Open Settings",
      cls: "mod-cta"
    });
    settingsButton.addEventListener("click", () => {
      this.app.setting.open();
      this.app.setting.openTabById("community-plugins");
      this.close();
    });
    const closeButton = buttonContainer.createEl("button", { text: "Close" });
    closeButton.addEventListener("click", () => {
      this.close();
    });
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var CalendarDateInputModal = class extends import_obsidian.Modal {
  constructor(app, calendarData, year, month, day, onSubmit) {
    super(app);
    this.dayDropdown = null;
    this.calendarData = calendarData;
    this.year = year || "1";
    this.month = month || "1";
    this.day = day || "1";
    this.onSubmit = onSubmit;
  }
  onOpen() {
    var _a, _b;
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: " Select Date" });
    const monthData = ((_b = (_a = this.calendarData) == null ? void 0 : _a.static) == null ? void 0 : _b.months) || [];
    const dateSetting = new import_obsidian.Setting(contentEl).setName("Date").setDesc("Select year, month, and day");
    dateSetting.addText((text) => {
      text.setPlaceholder("Year").setValue(this.year).onChange((value) => {
        this.year = value;
      });
      text.inputEl.style.width = "80px";
    });
    dateSetting.addDropdown((dropdown) => {
      monthData.forEach((month, index) => {
        const monthName = month.name || `Month ${index + 1}`;
        dropdown.addOption((index + 1).toString(), monthName);
      });
      dropdown.setValue(this.month || "1").onChange((value) => {
        this.month = value;
        this.updateDayDropdown();
      });
    });
    dateSetting.addDropdown((dropdown) => {
      this.dayDropdown = dropdown;
      this.updateDayDropdown();
      dropdown.setValue(this.day || "1").onChange((value) => {
        this.day = value;
      });
    });
    const buttonContainer = contentEl.createDiv({ cls: "dnd-modal-buttons" });
    const cancelButton = buttonContainer.createEl("button", { text: "Cancel" });
    cancelButton.addEventListener("click", () => {
      this.close();
    });
    const selectButton = buttonContainer.createEl("button", {
      text: "Select Date",
      cls: "mod-cta"
    });
    selectButton.addEventListener("click", () => {
      this.onSubmit(this.year, this.month, this.day);
      this.close();
    });
  }
  updateDayDropdown() {
    var _a, _b, _c;
    if (!this.dayDropdown) return;
    const monthData = ((_b = (_a = this.calendarData) == null ? void 0 : _a.static) == null ? void 0 : _b.months) || [];
    const monthIndex = parseInt(this.month || "1") - 1;
    const daysInMonth = ((_c = monthData[monthIndex]) == null ? void 0 : _c.length) || 30;
    this.dayDropdown.selectEl.empty();
    for (let d = 1; d <= daysInMonth; d++) {
      this.dayDropdown.addOption(d.toString(), d.toString());
    }
    if (parseInt(this.day) > daysInMonth) {
      this.day = daysInMonth.toString();
      this.dayDropdown.setValue(this.day);
    }
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
//# sourceMappingURL=main.js.map
